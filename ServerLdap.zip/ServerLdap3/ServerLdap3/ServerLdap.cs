﻿using System;
using System.Net;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using HtmlAgilityPack;
using ScrapySharp.Extensions;
namespace ServerLdap3
{
    public partial class ServerLdap : Form
    {
        public ServerLdap()
        {
            InitializeComponent();
        }

        private void ServerLdap_Load(object sender, EventArgs e)
        {
            //button1_Click(sender, e);
            Ejercicio();
            GetDefaultGateway();
            ShowConnectedID();
            GetMACAddress();
            FindVM();
            //WebScrappingVMVersionAttemp();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Welcome");

            DialogResult dr = MessageBox.Show("Do you want to close this window?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if(dr == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void Ejercicio()
        {
            //IP Address
            string _hostName = Dns.GetHostName();
            IPAddress[] _ipList = Dns.GetHostAddresses(_hostName)/*.AddressList*/;

            foreach (IPAddress  ip in _ipList)
            {
                label1.Text = string.Format("IP Host: {0}\n", ip);
            }
            
            //Gateway IP
            label2.Text = string.Format("IP Gateway: {0}\n", GetDefaultGateway());
            
            //Username
            string username = System.Windows.Forms.SystemInformation.UserName;
            label4.Text = "Username: " + username;
            
            //HostName
            string hostname = System.Windows.Forms.SystemInformation.ComputerName;
            label5.Text = "Hostname: " + hostname;

            
            //Ping CLoudflare
            Ping pingClass = new Ping();
            PingReply pingReply = pingClass.Send("1.1.1.1", 1000);
            int contadorPing = 0;
            for (int i = 0; i < 4; i++)
            {
                if (pingReply.Status == IPStatus.Success)
                {
                    contadorPing++;
                    if (contadorPing <= 0)
                    {
                        label9.Text = "Cloudflare Connection: Disconnected";
                    }
                    if(contadorPing > 0 && contadorPing <= 3)
                    {
                        label9.Text = "Cloudflare Connection: Unstable";
                    }
                    if(contadorPing >= 4)
                    {
                        label9.Text = "Cloudflare Connection: Connected";
                    }
                }

            }
        }

        public static IPAddress GetDefaultGateway()
        {
            var gateway_address = NetworkInterface.GetAllNetworkInterfaces().Where(e => e.OperationalStatus == OperationalStatus.Up)
                .SelectMany(e => e.GetIPProperties().GatewayAddresses).FirstOrDefault();
            if(gateway_address == null)
            {
                return null;
            }
            return gateway_address.Address;
        }

        private void ShowConnectedID()
        {
            System.Diagnostics.Process p = new System.Diagnostics.Process();
            p.StartInfo.FileName = "netsh.exe";
            p.StartInfo.Arguments = "wlan show interfaces";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.Start();

            string s = p.StandardOutput.ReadToEnd();
            string s1 = s.Substring(s.IndexOf("SSID"));
            s1 = s1.Substring(s1.IndexOf(":"));
            s1 = s1.Substring(2, s1.IndexOf("\n")).Trim();

            string estado = "";
            bool RedActiva = System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable();

            if (RedActiva)
            {
                estado = "Conectado";
            }
            if(RedActiva == false)
            {
                estado = "No Conectado";
            }
            //SSID Name
            label6.Text = "SSID: " + s1;
            //SSID Status
            label7.Text = "SSID Status: " + estado;
            p.WaitForExit();
        }

        public void GetMACAddress()
        {
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            String sMacAddress = string.Empty;
            foreach (NetworkInterface adapter in nics)
            {
                if (sMacAddress == String.Empty)// only return MAC Address from first card  
                {
                    IPInterfaceProperties properties = adapter.GetIPProperties();
                    sMacAddress = adapter.GetPhysicalAddress().ToString();
                }
            }
            //MAC
            label8.Text = "MAC Address: " + sMacAddress;
        }

        public void FindVM()
        {
            string cmd = "/C" + "\"C:\\Program Files\\Oracle\\VirtualBox\\VBoxManage.exe\" --version";

            System.Diagnostics.Process p = new System.Diagnostics.Process();
            p.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            p.StartInfo.FileName = "cmd.exe";
            p.StartInfo.Arguments = cmd;
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.Start();

            string VM = "";
            while(!p.HasExited)
            {
                VM = VM + p.StandardOutput.ReadToEnd();
            }

            if(VM != "")
            {
                label10.Text = "is VirtualBox Installed? "+"Yes";
                string VM_Version = VM.Substring(0, VM.IndexOf("r"));
                label12.Text = VM_Version;
                if (VM_Version.Equals("7.0.6"))
                {
                    label12.Text = "is Latest Version Installed? " + VM_Version +" Yes";
                }
                if (!VM_Version.Equals("7.0.6"))
                {
                    label12.Text = "is Latest Version Installed? " + VM_Version + " No";
                }
            }
            if (VM.Equals(""))
            {
                label10.Text = "is VirtualBox Installed? " + "No";
                label12.Text = label12.Text = "N/A";

            }
        }

        public void WebScrappingVMVersionAttemp()
        {
            
            string url = "https://www.virtualbox.org/wiki/Downloads";

            HtmlWeb web = new HtmlWeb();
            HtmlAgilityPack.HtmlDocument html = web.Load(url);

            var nodes = html.DocumentNode.CssSelect("[class='wiki' ]").Select(x => x.InnerHtml).Distinct();

            
            nodes.ToList().ForEach(e =>
            {
                label12.Text = nodes.ToString();
            });
        }
    }
}
